import React, { useState, useMemo } from 'react';
import { 
  Calculator, 
  TrendingUp, 
  DollarSign, 
  Percent, 
  Truck, 
  RotateCcw, 
  Info,
  ArrowRight,
  BarChart3,
  PieChart as PieChartIcon,
  ShieldCheck
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

interface InputState {
  sellingPrice: number;
  productCost: number;
  platformFee: number;
  shippingFee: number;
  returnRate: number;
}

export default function App() {
  const [inputs, setInputs] = useState<InputState>({
    sellingPrice: 100,
    productCost: 30,
    platformFee: 5,
    shippingFee: 5,
    returnRate: 20,
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setInputs(prev => ({
      ...prev,
      [name]: parseFloat(value) || 0,
    }));
  };

  const results = useMemo(() => {
    const { sellingPrice, productCost, platformFee, shippingFee, returnRate } = inputs;

    // 1. 单单毛利 (Gross Profit per order before ads)
    const platformFeeAmount = sellingPrice * (platformFee / 100);
    const grossProfit = sellingPrice - productCost - shippingFee - platformFeeAmount;
    
    // 2. 保本ROI (Break-even ROI)
    const grossProfitMargin = grossProfit / sellingPrice;
    const breakEvenRoi = grossProfitMargin > 0 ? 1 / grossProfitMargin : 0;

    // 3. 盈利ROI计算 (Target ROI for specific profit margins)
    // k = ratio of costs to gross revenue
    const k = (productCost / sellingPrice) + (platformFee / 100) + (shippingFee / sellingPrice);
    // r = net revenue ratio (after returns)
    const r = 1 - (returnRate / 100);

    // Formula: ROI = (k + 1) / (r * (1 - NPM))
    const calculateTargetRoi = (targetNpm: number) => {
      const denominator = r * (1 - targetNpm);
      return denominator > 0 ? (k + 1) / denominator : 0;
    };

    const recommendedRoi10 = calculateTargetRoi(0.1); // 10% Net Profit Margin
    const recommendedRoi20 = calculateTargetRoi(0.2); // 20% Net Profit Margin

    // 4. Chart Data: Profit vs ROI (Range around break-even)
    const startRoi = Math.max(1, Math.floor(breakEvenRoi) - 2);
    const chartData = Array.from({ length: 10 }, (_, i) => {
      const currentRoi = startRoi + i;
      const netRev = currentRoi * r;
      const prodCost = currentRoi * (productCost / sellingPrice);
      const platFee = currentRoi * (platformFee / 100);
      const shipFee = currentRoi * (shippingFee / sellingPrice);
      const profit = netRev - prodCost - platFee - shipFee - 1;
      return {
        roi: currentRoi,
        profit: parseFloat(profit.toFixed(2)),
      };
    });

    const pieData = [
      { name: '产品成本', value: productCost },
      { name: '平台扣点', value: platformFeeAmount },
      { name: '运费', value: shippingFee },
      { name: '毛利', value: Math.max(0, grossProfit) },
    ];

    return {
      grossProfit,
      breakEvenRoi,
      recommendedRoi10,
      recommendedRoi20,
      chartData,
      pieData,
      platformFeeAmount
    };
  }, [inputs]);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444'];

  return (
    <div className="min-h-screen bg-[#F5F5F5] text-[#1A1A1A] font-sans p-4 md:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
              <Calculator className="w-8 h-8 text-emerald-600" />
              千川净成交ROI计算器
            </h1>
            <p className="text-stone-500 mt-1">专业电商投放保本与推荐盈利分析工具</p>
          </div>
          <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-2xl shadow-sm border border-stone-200">
            <ShieldCheck className="w-5 h-5 text-emerald-500" />
            <span className="text-sm font-medium">自动计算推荐ROI</span>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Inputs */}
          <div className="lg:col-span-4 space-y-6">
            <section className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200 space-y-6">
              <h2 className="text-lg font-semibold flex items-center gap-2 border-b border-stone-100 pb-4">
                <ArrowRight className="w-4 h-4 text-emerald-600" />
                输入参数
              </h2>
              
              <div className="space-y-4">
                <InputField 
                  label="商品售价 (元)" 
                  name="sellingPrice" 
                  value={inputs.sellingPrice} 
                  onChange={handleInputChange}
                  icon={<DollarSign className="w-4 h-4" />}
                />
                <InputField 
                  label="产品成本 (元)" 
                  name="productCost" 
                  value={inputs.productCost} 
                  onChange={handleInputChange}
                  icon={<Info className="w-4 h-4" />}
                />
                <InputField 
                  label="平台扣点 (%)" 
                  name="platformFee" 
                  value={inputs.platformFee} 
                  onChange={handleInputChange}
                  icon={<Percent className="w-4 h-4" />}
                />
                <InputField 
                  label="单单运费 (元)" 
                  name="shippingFee" 
                  value={inputs.shippingFee} 
                  onChange={handleInputChange}
                  icon={<Truck className="w-4 h-4" />}
                />
                <InputField 
                  label="退货率 (%)" 
                  name="returnRate" 
                  value={inputs.returnRate} 
                  onChange={handleInputChange}
                  icon={<RotateCcw className="w-4 h-4" />}
                />
              </div>
            </section>

            {/* Cost Breakdown Pie Chart */}
            <section className="bg-white rounded-3xl p-6 shadow-sm border border-stone-200">
              <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <PieChartIcon className="w-4 h-4 text-emerald-600" />
                单品成本构成
              </h2>
              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={results.pieData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {results.pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </div>
              <div className="grid grid-cols-2 gap-2 mt-4">
                {results.pieData.map((item, index) => (
                  <div key={item.name} className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index] }} />
                    <span className="text-stone-600">{item.name}: {item.value.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </section>
          </div>

          {/* Right Column: Results & Charts */}
          <div className="lg:col-span-8 space-y-8">
            {/* Key Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <ResultCard 
                title="保本 ROI" 
                value={results.breakEvenRoi.toFixed(2)} 
                subtitle="低于此值即亏损"
                highlight
              />
              <ResultCard 
                title="推荐盈利 ROI (10%)" 
                value={results.recommendedRoi10.toFixed(2)} 
                subtitle="实现10%净利润率"
                color="text-emerald-600"
              />
              <ResultCard 
                title="进取盈利 ROI (20%)" 
                value={results.recommendedRoi20.toFixed(2)} 
                subtitle="实现20%净利润率"
                color="text-blue-600"
              />
            </div>

            {/* Profit Analysis Chart */}
            <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-xl font-bold flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-emerald-600" />
                    ROI 盈利敏感度分析
                  </h2>
                  <p className="text-stone-500 text-sm">每投入1元广告费所获得的净利润随ROI的变化趋势</p>
                </div>
              </div>
              
              <div className="h-80 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={results.chartData}>
                    <defs>
                      <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="roi" 
                      label={{ value: '投放ROI', position: 'insideBottom', offset: -5 }}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis 
                      label={{ value: '单均净利', angle: -90, position: 'insideLeft' }}
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip 
                      contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                      formatter={(value: number) => [`${value} 元`, '净利润']}
                      labelFormatter={(label) => `ROI: ${label}`}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="profit" 
                      stroke="#10b981" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorProfit)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </section>

            {/* Detailed Breakdown Table */}
            <section className="bg-white rounded-3xl p-8 shadow-sm border border-stone-200 overflow-hidden">
              <h2 className="text-xl font-bold mb-6">详细财务拆解</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-stone-100">
                      <th className="pb-4 font-semibold text-stone-500 text-sm uppercase tracking-wider">项目</th>
                      <th className="pb-4 font-semibold text-stone-500 text-sm uppercase tracking-wider">数值</th>
                      <th className="pb-4 font-semibold text-stone-500 text-sm uppercase tracking-wider">说明</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-50">
                    <TableRow label="单件毛利" value={`${results.grossProfit.toFixed(2)} 元`} desc="售价 - 成本 - 运费 - 平台扣点" />
                    <TableRow label="平台扣点金额" value={`${results.platformFeeAmount.toFixed(2)} 元`} desc={`售价 × ${inputs.platformFee}%`} />
                    <TableRow label="退货损失预估" value={`${(inputs.sellingPrice * inputs.returnRate / 100).toFixed(2)} 元`} desc="基于售价与退货率的销售损失" />
                    <TableRow label="保本毛利率" value={`${((results.grossProfit / inputs.sellingPrice) * 100).toFixed(1)}%`} desc="未计算广告费前的利润空间" />
                  </tbody>
                </table>
              </div>
            </section>
          </div>
        </div>

        {/* Footer Info */}
        <footer className="text-center text-stone-400 text-sm pb-8">
          <p>© 2024 千川投放助手 · 仅供参考，请以实际财务报表为准</p>
        </footer>
      </div>
    </div>
  );
}
function InputField({ label, name, value, onChange, icon }: { 
  label: string; 
  name: string; 
  value: number; 
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  icon: React.ReactNode;
}) {
  return (
    <div className="space-y-2">
      <label className="text-sm font-medium text-stone-600 flex items-center gap-2">
        {icon}
        {label}
      </label>
      <input
        type="number"
        name={name}
        value={value}
        onChange={onChange}
        className="w-full bg-stone-50 border border-stone-200 rounded-xl px-4 py-2.5 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-mono"
      />
    </div>
  );
}

function ResultCard({ title, value, subtitle, highlight, color }: { 
  title: string; 
  value: string; 
  subtitle: string; 
  highlight?: boolean;
  color?: string;
}) {
  return (
    <div className={cn(
      "p-6 rounded-3xl border shadow-sm transition-all hover:shadow-md",
      highlight ? "bg-emerald-600 border-emerald-500 text-white" : "bg-white border-stone-200 text-[#1A1A1A]"
    )}>
      <p className={cn("text-sm font-medium mb-1", highlight ? "text-emerald-100" : "text-stone-500")}>{title}</p>
      <p className={cn("text-3xl font-bold tracking-tight mb-2", color)}>{value}</p>
      <p className={cn("text-xs", highlight ? "text-emerald-200" : "text-stone-400")}>{subtitle}</p>
    </div>
  );
}

function TableRow({ label, value, desc }: { label: string; value: string; desc: string }) {
  return (
    <tr>
      <td className="py-4 font-medium text-stone-800">{label}</td>
      <td className="py-4 font-mono font-semibold text-emerald-600">{value}</td>
      <td className="py-4 text-sm text-stone-400">{desc}</td>
    </tr>
  );
}
